const tracks = [

  {

    name: "No Copy Vibes",

    artist: "MC Jan",

    url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",

    cover: "https://picsum.photos/seed/cover1/100"

  },

  {

    name: "Batida do Iago",

    artist: "DJ Iaguin",

    url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",

    cover: "https://picsum.photos/seed/cover2/100"

  },

  {

    name: "Trap do Espaço",

    artist: "Jovem Nébula",

    url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",

    cover: "https://picsum.photos/seed/cover3/100"

  }

];

const trackList = document.getElementById("trackList");

const player = document.getElementById("player");

const search = document.getElementById("search");

function renderTracks(filter = "") {

  trackList.innerHTML = "";

  tracks

    .filter(track =>

      track.name.toLowerCase().includes(filter.toLowerCase()) ||

      track.artist.toLowerCase().includes(filter.toLowerCase())

    )

    .forEach((track, index) => {

      const div = document.createElement("div");

      div.classList.add("track");

      div.innerHTML = `

        <div class="track-info">

          <img src="${track.cover}" alt="Capa">

          <div>

            <strong>${track.name}</strong><br>

            <small>${track.artist}</small>

          </div>

        </div>

        <button>▶</button>

      `;

      div.addEventListener("click", () => {

        player.src = track.url;

        player.classList.remove("hidden");

        player.play();

      });

      trackList.appendChild(div);

    });

}

search.addEventListener("input", e => {

  renderTracks(e.target.value);

});

renderTracks();